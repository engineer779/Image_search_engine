// scripts.js

$(function () {
  $("body").on("click", ".ajax-link", function (e) {
    e.preventDefault();

    var url = $(this).attr("href");

    $.ajax({
      url: url,
      type: "GET",
      success: function (response) {
        var $html = $(response);
        var $newContent = $html.find("#page-content").html();
        var $pageTitle = $html.find("title").text();

        $("title").text($pageTitle);
        $("#page-content").html($newContent).addClass("fade-in");
      },
    });
  });
});
