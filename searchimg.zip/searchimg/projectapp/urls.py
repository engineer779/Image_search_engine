from django.contrib import admin
from django.urls import path, include

from projectapp.veiws1 import image_search
# from projectapp import views
from . import views


urlpatterns = [
    path("", views.index, name="projectapp"),
    path("signup", views.SignupViews.as_view(), name="signup"),
    path("login", views.LoginViews.as_view(), name="login"),
    path("search", views.SearchView.as_view()),
    path("signout", views.signout, name="signout"),
    path('search/', image_search, name='image_search'),
    path('search/', views.index, name='projectapp'),




]
