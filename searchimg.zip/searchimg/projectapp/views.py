from datetime import datetime
from django.shortcuts import render, redirect
from django.contrib.auth.models import User
from django.contrib import messages
from django.http import HttpResponse
from django.contrib.auth import authenticate, login, logout
from django.views import View
from django.contrib.auth.forms import UserCreationForm
from serpapi import GoogleSearch

# Create your views here.


def index(request):
    return render(request, "index.html")


# def login(request):
#    if request.method == "POST":
#        username = request.POST["username"]
#        password = request.POST["password"]
#
#        user = authenticate(username=username, password=password)
#
#        if user is not None:
#            login(request, user)
#            fname = user.first_name
#            return render(request, "search", {"fname": fname})
#
#        else:
#            messages.error(request, "bad credentials !!")
#            return redirect("home")
#
#    return render(request, "login.html")
#
#
def signout(request):
    logout(request)
    messages.success(request, "logged out successfully")
    return redirect("home")
#
#
# def signup(request):
#
#    if request.method == "post":
#        # username = request.POST.get("username")
#        username = request.get("username")
#        fname = request.POST.get("fname")
#        lname = request.POST.get("lname")
#        email = request.POST.get("email")
#        password = request.get("password")
#
#        my_user = User.objects.create_user(username, email, password)
#
#        my_user.first_name = fname
#        my_user.last_name = lname
#
#        my_user.save()
#
#        messages.success(
#            request, "Your Account has been successfully created !!!! ")
#
#        return redirect("login")
#
#    return render(request, "signup.html")


class LoginViews(View):
    def get(self, request):
        return render(request, "login.html")

    def post(self, request):

        username = request.POST["username"]
        password = request.POST["password"]

        user = authenticate(username=username, password=password)

        if user is not None:
            login(request, user)
            fname = user.first_name
            return render(request, "search.html", {"fname": fname})

        else:
            messages.error(request, "bad credentials !!")
            return render(request, "login.html")

        return render(request, "login.html")


class SignupViews(View):
    def get(self, request):
        return render(request, "signup.html")

    def post(self, request):

        user_created = request.POST
        username = request.POST.get("username")
        fname = request.POST.get("fname")
        lname = request.POST.get("lname")
        email = request.POST.get("email")
        password = request.POST.get("password")

        my_user = User.objects.create_user(username, email, password)

        my_user.first_name = fname
        my_user.last_name = lname

        my_user.save()

        messages.success(
            request, "Your Account has been successfully created !!!! ")

        return redirect("login")
      #  return render(request, "signup.html")


class SearchView(View):

    def Serpapi():
        params = {
            "q": "banana",
            "location": "Austin, Texas, United States",
            "google_domain": "google.com",
            "hl": "en",
            "gl": "us",
            "api_key": "secret_api_key"
        }

        search = GoogleSearch(params)
        results = search.get_dict()
        inline_images = results["inline_images"]
