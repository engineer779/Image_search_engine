import requests
from googlesearch import search
from django.http import JsonResponse


def image_search(request):
    search_query = request.GET.get('query')
    urls = []
    for j in search(search_query, num=10, stop=10):
        if 'png' in j or 'jpg' in j or 'jpeg' in j:
            urls.append(j)
    return JsonResponse({'urls': urls})
